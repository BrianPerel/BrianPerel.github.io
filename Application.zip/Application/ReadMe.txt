Thank you for downloading my ATM program.

*** All program resources such as program reciept file and data save file will be saved in resources folder *** 

Enjoy,
Brian Perel 